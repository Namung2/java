package project.objetArrayEx;

import java.util.*;
import java.lang.*;
import java.io.*;
import project.objetArrayEx.Goods;//다른소스의 클래스 사용하기
//패키지명.사용할 클래스명
//이건 다른 패키지에 있는 클래스를 불러올때도 동일하다.

//객체 배열 예제
public class GoodsArray {
    public static void main(String[] args){
    Goods[] goodsArray;
    goodsArray=new Goods[3];//Goods를 담는 3개의 객체 생성
    Scanner s=new Scanner(System.in);
        
    for(int i=0;i<goodsArray.length;i++)
    {
    String name = s.next();
    int price =s.nextInt();
    int n=s.nextInt();
    int sold = s.nextInt();
    goodsArray[i]= new Goods(name,price,n,sold);
        // new를 사용해 실제 3개의 객체에 각각 순서대로 메모리 할당함.
    }
    
    for(int i=0;i<goodsArray.length;i++){
        System.out.print(goodsArray[i].getName()+" ");
        System.out.print(goodsArray[i].getPrice()+" ");
        System.out.print(goodsArray[i].getNumberOfS()+" ");
        System.out.println(goodsArray[i].getsold()+" ");
    }
        s.close();
    }
}
//Goods 클래스와 GoodsArray는 연관 관계(association)
