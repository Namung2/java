package project.objetArrayEx;

class Goods{//다른모든클래스에서 클래스를 사용하려면 public꼭 붙히자
            //같은 패키지(디렉토리)에있는 클래스끼리는 public없이 접근 가능함
                
    private String name;
    private int price;
    private int numberOfSt;
    private int sold;//여기까지 필드

    Goods(String n,int p,int nStock,int s){
        name=n;
        price=p;
        numberOfSt=nStock;
        sold=s;
    }//여기까지 생성자
    
    String getName(){return name;}
    int getPrice(){return price;}
    int getNumberOfS(){return numberOfSt;}
    int getsold(){return sold;}//여기까지 메소드
    
}